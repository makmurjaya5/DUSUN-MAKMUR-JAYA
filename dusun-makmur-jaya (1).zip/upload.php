<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = $_POST['judul'];
    $konten = $_POST['konten'];
    $tanggal = date('Y-m-d');

    $uploadPath = '';
    if (!empty($_FILES['dokumen']['name'])) {
        $fileName = basename($_FILES['dokumen']['name']);
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir);
        $targetFile = $targetDir . time() . "_" . $fileName;
        if (move_uploaded_file($_FILES['dokumen']['tmp_name'], $targetFile)) {
            $uploadPath = $targetFile;
        }
    }

    $beritaFile = 'berita.json';
    $beritaList = file_exists($beritaFile) ? json_decode(file_get_contents($beritaFile), true) : [];

    $beritaBaru = [
        'judul' => $judul,
        'konten' => $konten . ($uploadPath ? "<br><a href='$uploadPath'>Unduh Dokumen</a>" : ""),
        'tanggal' => $tanggal
    ];
    $beritaList[] = $beritaBaru;

    file_put_contents($beritaFile, json_encode($beritaList, JSON_PRETTY_PRINT));
    header("Location: index.html");
    exit;
}
?>